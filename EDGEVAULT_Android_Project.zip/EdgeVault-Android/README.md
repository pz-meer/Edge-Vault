# EDGEVAULT Android project

The supplied EDGEVAULT HTML trading journal is bundled at `app/src/main/assets/index.html`. The Android WebView enables JavaScript, local browser storage/IndexedDB, and file picking for HTML upload controls. Built for Android SDK 36 with Java 17.
